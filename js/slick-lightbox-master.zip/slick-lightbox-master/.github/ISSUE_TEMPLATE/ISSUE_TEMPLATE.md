Issue tracker is used **only for reporting issues**. For support, go to [Stack Overflow](https://stackoverflow.com/) or similar.
